/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package productsalesreport;

public class Product implements IProduct {
    private final String[] productNames;
    private final int[][] monthlySales;

    public Product(String[] productNames, int[][] monthlySales) {
        if (productNames == null || monthlySales == null
                || productNames.length != monthlySales.length
                || productNames.length == 0) {
            throw new IllegalArgumentException(
                    "Product names and sales must have matching, non-empty data.");
        }

        this.productNames = productNames.clone();
        this.monthlySales = new int[monthlySales.length][];

        for (int i = 0; i < monthlySales.length; i++) {
            if (monthlySales[i] == null || monthlySales[i].length == 0) {
                throw new IllegalArgumentException(
                        "Each product must have at least one monthly sales value.");
            }

            this.monthlySales[i] = monthlySales[i].clone();

            for (int sale : this.monthlySales[i]) {
                if (sale < 0) {
                    throw new IllegalArgumentException("Sales cannot be negative.");
                }
            }
        }
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;

        for (int[] productSales : monthlySales) {
            for (int sale : productSales) {
                total += sale;
            }
        }

        return total;
    }

    @Override
    public double GetAverageProductsSold() {
        int totalMonths = 0;

        for (int[] productSales : monthlySales) {
            totalMonths += productSales.length;
        }

        return (double) GetTotalProductsSold() / totalMonths;
    }

    @Override
    public String GetMostPopularProduct() {
        int mostPopularIndex = 0;
        int highestSales = -1;

        for (int i = 0; i < monthlySales.length; i++) {
            int productTotal = 0;

            for (int sale : monthlySales[i]) {
                productTotal += sale;
            }

            if (productTotal > highestSales) {
                highestSales = productTotal;
                mostPopularIndex = i;
            }
        }

        return productNames[mostPopularIndex];
    }
}
