/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package productsalesreport;

import java.util.Scanner;

/**
 *
 * @author GHOST
 */

public class Main {
    public static void main(String[] args) {
        String[] productNames = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        int[][] sales = new int[productNames.length][3];

        try (Scanner input = new Scanner(System.in)) {
            for (int product = 0; product < productNames.length; product++) {
                for (int month = 0; month < 3; month++) {
                    sales[product][month] = readSales(
                            input, month + 1, productNames[product]);
                }
                System.out.println();
            }
        }

        Product product = new Product(productNames, sales);
        PrintProduct report = new PrintProduct(product);
        report.printReport();
    }

    private static int readSales(Scanner input, int month, String productName) {
        while (true) {
            System.out.print("Enter number of sales for month "
                    + month + " for " + productName + ": ");

            if (input.hasNextInt()) {
                int sales = input.nextInt();

                if (sales >= 0) {
                    return sales;
                }
            } else {
                input.next(); // Discard invalid input.
            }

            System.out.println("Please enter a whole number that is 0 or greater.");
        }
    }
}